<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/security.php';

requireLogin();

$incidentId = (int)($_GET['id'] ?? 0);

if ($incidentId <= 0) {
    die('Invalid incident ID.');
}


/*
|--------------------------------------------------------------------------
| Get Incident
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare(
    "SELECT
        i.*,

        c.name AS category_name,

        reporter.name AS reporter_name,
        reporter.email AS reporter_email,

        analyst.name AS analyst_name,
        analyst.email AS analyst_email

     FROM incidents i

     LEFT JOIN incident_categories c
        ON i.category_id = c.id

     LEFT JOIN users reporter
        ON i.reported_by = reporter.id

     LEFT JOIN users analyst
        ON i.assigned_to = analyst.id

     WHERE i.id = ?

     LIMIT 1"
);

$stmt->execute([$incidentId]);

$incident = $stmt->fetch();

if (!$incident) {

    http_response_code(404);

    die('Incident not found.');
}


/*
|--------------------------------------------------------------------------
| Access Control
|--------------------------------------------------------------------------
*/

if ($_SESSION['role'] === 'analyst') {

    if (
        (int)$incident['assigned_to']
        !==
        (int)$_SESSION['user_id']
    ) {

        http_response_code(403);

        die(
            'Access Denied: This incident is not assigned to you.'
        );
    }

} elseif ($_SESSION['role'] !== 'admin') {

    http_response_code(403);

    die('Access Denied.');
}


/*
|--------------------------------------------------------------------------
| Activity History
|--------------------------------------------------------------------------
*/

$activityStmt = $pdo->prepare(
    "SELECT
        ia.*,
        u.name AS user_name,
        u.email AS user_email,
        u.role AS user_role

     FROM incident_activity ia

     LEFT JOIN users u
        ON ia.user_id = u.id

     WHERE ia.incident_id = ?

     ORDER BY ia.created_at ASC"
);

$activityStmt->execute([
    $incidentId
]);

$activities = $activityStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Investigation Comments
|--------------------------------------------------------------------------
*/

$commentStmt = $pdo->prepare(
    "SELECT
        ic.id,
        ic.comment,
        ic.created_at,

        u.name AS user_name,
        u.email AS user_email,
        u.role AS user_role

     FROM incident_comments ic

     LEFT JOIN users u
        ON ic.user_id = u.id

     WHERE ic.incident_id = ?

     ORDER BY ic.created_at DESC"
);

$commentStmt->execute([
    $incidentId
]);

$comments = $commentStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Evidence Files
|--------------------------------------------------------------------------
*/

$evidenceStmt = $pdo->prepare(
    "SELECT
        ie.id,
        ie.original_name,
        ie.stored_name,
        ie.mime_type,
        ie.file_size,
        ie.file_hash,
        ie.created_at,

        u.name AS uploader_name,
        u.email AS uploader_email,
        u.role AS uploader_role

     FROM incident_evidence ie

     LEFT JOIN users u
        ON ie.uploaded_by = u.id

     WHERE ie.incident_id = ?

     ORDER BY ie.created_at DESC"
);

$evidenceStmt->execute([
    $incidentId
]);

$evidenceFiles = $evidenceStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Success Messages
|--------------------------------------------------------------------------
*/

$successMessage = '';

if (isset($_GET['created'])) {

    $successMessage =
        'Incident ' .
        $incident['ticket_number'] .
        ' was created successfully.';

} elseif (isset($_GET['updated'])) {

    $successMessage =
        'Incident was updated successfully.';

} elseif (isset($_GET['assigned'])) {

    $successMessage =
        'Incident assignment was updated successfully.';

} elseif (isset($_GET['status_updated'])) {

    $successMessage =
        'Incident status was updated successfully.';

} elseif (isset($_GET['comment_added'])) {

    $successMessage =
        'Investigation note was added successfully.';

} elseif (isset($_GET['evidence_added'])) {

    $successMessage =
        'Evidence uploaded successfully.';
}


/*
|--------------------------------------------------------------------------
| Comment Error
|--------------------------------------------------------------------------
*/

$commentError = '';

if (isset($_GET['comment_error'])) {

    if ($_GET['comment_error'] === 'empty') {

        $commentError =
            'Investigation note cannot be empty.';

    } elseif (
        $_GET['comment_error'] === 'length'
    ) {

        $commentError =
            'Investigation note cannot exceed 5000 characters.';

    } else {

        $commentError =
            'Unable to add investigation note.';
    }
}


/*
|--------------------------------------------------------------------------
| Evidence Error
|--------------------------------------------------------------------------
*/

$evidenceError = '';

if (isset($_GET['evidence_error'])) {

    switch ($_GET['evidence_error']) {

        case 'no_file':

            $evidenceError =
                'Please select an evidence file.';

            break;

        case 'upload':

            $evidenceError =
                'File upload failed.';

            break;

        case 'size':

            $evidenceError =
                'File size must be between 1 byte and 10 MB.';

            break;

        case 'type':

            $evidenceError =
                'This file extension is not allowed.';

            break;

        case 'mime':

            $evidenceError =
                'File content type is not allowed.';

            break;

        case 'hash':

            $evidenceError =
                'Unable to calculate file integrity hash.';

            break;

        case 'save':

            $evidenceError =
                'Unable to save the uploaded file.';

            break;

        case 'database':

            $evidenceError =
                'Unable to save evidence information to database.';

            break;

        default:

            $evidenceError =
                'Evidence upload failed.';
    }
}


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

$statusLabels = [
    'open' => 'Open',
    'in_progress' => 'In Progress',
    'resolved' => 'Resolved',
    'closed' => 'Closed'
];


$statusClass = [
    'open' => 'open',
    'in_progress' => 'in-progress',
    'resolved' => 'resolved',
    'closed' => 'closed'
];


$severityClass = [
    'low' => 'low',
    'medium' => 'medium',
    'high' => 'high',
    'critical' => 'critical'
];


/*
|--------------------------------------------------------------------------
| File Size Formatter
|--------------------------------------------------------------------------
*/

function formatFileSize(int $bytes): string
{
    if ($bytes <= 0) {
        return '0 B';
    }

    $units = [
        'B',
        'KB',
        'MB',
        'GB'
    ];

    $index = 0;

    while (
        $bytes >= 1024
        &&
        $index < count($units) - 1
    ) {

        $bytes /= 1024;

        $index++;
    }

    return number_format(
        $bytes,
        $index === 0 ? 0 : 2
    )
    . ' '
    . $units[$index];
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>

    <?= e(
        $incident['ticket_number']
    ) ?>

    |

    Security Incident

</title>


<style>

* {
    box-sizing: border-box;
}


body {

    margin: 0;

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #0f172a;

    color: #f8fafc;
}


/* =========================================================
   NAVBAR
========================================================= */

.navbar {

    background: #111827;

    border-bottom:
        1px solid #263244;

    padding: 18px 30px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;
}


.brand {

    font-size: 18px;

    font-weight: 700;
}


.navbar a {

    color: #cbd5e1;

    text-decoration: none;

    margin-left: 18px;
}


.navbar a:hover {

    color: white;
}


/* =========================================================
   CONTAINER
========================================================= */

.container {

    max-width: 1250px;

    margin: auto;

    padding: 30px;
}


/* =========================================================
   SUCCESS / ERROR
========================================================= */

.success {

    background: #052e16;

    border:
        1px solid #166534;

    color: #86efac;

    padding: 15px 18px;

    border-radius: 10px;

    margin-bottom: 22px;

    font-weight: 600;
}


.error {

    background: #450a0a;

    border:
        1px solid #7f1d1d;

    color: #fecaca;

    padding: 15px 18px;

    border-radius: 10px;

    margin-bottom: 22px;

    font-weight: 600;
}


/* =========================================================
   INCIDENT HEADER
========================================================= */

.incident-header {

    background: #111827;

    border:
        1px solid #263244;

    border-radius: 15px;

    padding: 28px;

    margin-bottom: 20px;
}


.ticket {

    color: #38bdf8;

    font-size: 14px;

    font-weight: 700;

    margin-bottom: 8px;
}


.incident-header h1 {

    margin: 0 0 18px;

    font-size: 30px;
}


.badges {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;
}


/* =========================================================
   BADGES
========================================================= */

.badge {

    display: inline-block;

    padding: 7px 13px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 700;
}


.category {

    background: #312e81;

    color: #c7d2fe;
}


.low {

    background: #064e3b;

    color: #a7f3d0;
}


.medium {

    background: #78350f;

    color: #fde68a;
}


.high {

    background: #7f1d1d;

    color: #fecaca;
}


.critical {

    background: #450a0a;

    color: #fca5a5;
}


.open {

    background: #172554;

    color: #bfdbfe;
}


.in-progress {

    background: #164e63;

    color: #a5f3fc;
}


.resolved {

    background: #14532d;

    color: #bbf7d0;
}


.closed {

    background: #374151;

    color: #d1d5db;
}


/* =========================================================
   MAIN GRID
========================================================= */

.grid {

    display: grid;

    grid-template-columns:
        minmax(0, 2fr)
        minmax(320px, 1fr);

    gap: 20px;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: #111827;

    border:
        1px solid #263244;

    border-radius: 15px;

    padding: 25px;

    margin-bottom: 20px;
}


.card h2 {

    margin: 0 0 18px;

    font-size: 20px;
}


.card h2::after {

    content: "";

    display: block;

    width: 100%;

    height: 1px;

    background: #263244;

    margin-top: 14px;
}


/* =========================================================
   DESCRIPTION
========================================================= */

.description {

    color: #cbd5e1;

    line-height: 1.7;

    white-space: pre-wrap;
}


/* =========================================================
   DETAILS
========================================================= */

.detail-row {

    display: flex;

    justify-content: space-between;

    gap: 20px;

    padding: 13px 0;

    border-bottom:
        1px solid #1e293b;
}


.detail-row:last-child {

    border-bottom: none;
}


.detail-label {

    color: #94a3b8;
}


.detail-value {

    text-align: right;

    font-weight: 600;

    word-break: break-word;
}


/* =========================================================
   TIMELINE
========================================================= */

.timeline {

    position: relative;

    margin-top: 10px;
}


.timeline::before {

    content: "";

    position: absolute;

    left: 10px;

    top: 0;

    bottom: 0;

    width: 2px;

    background: #334155;
}


.timeline-item {

    position: relative;

    padding-left: 38px;

    margin-bottom: 28px;
}


.timeline-item:last-child {

    margin-bottom: 0;
}


.timeline-dot {

    position: absolute;

    left: 3px;

    top: 4px;

    width: 16px;

    height: 16px;

    border-radius: 50%;

    background: #38bdf8;

    border:
        3px solid #0f172a;

    box-shadow:
        0 0 0 2px #38bdf8;
}


.timeline-content {

    background: #0f172a;

    border:
        1px solid #263244;

    border-radius: 10px;

    padding: 15px;
}


.timeline-title {

    font-weight: 700;

    margin-bottom: 7px;
}


.timeline-user {

    color: #38bdf8;

    font-size: 13px;

    margin-bottom: 8px;
}


.timeline-comment {

    color: #cbd5e1;

    line-height: 1.5;

    margin-top: 10px;

    white-space: pre-wrap;

    word-break: break-word;
}


.timeline-values {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 10px;

    margin-top: 12px;
}


.value-box {

    background: #111827;

    border:
        1px solid #263244;

    padding: 10px;

    border-radius: 7px;
}


.value-label {

    color: #64748b;

    font-size: 11px;

    margin-bottom: 5px;
}


.value-text {

    color: #e2e8f0;

    font-size: 13px;

    word-break: break-word;
}


.timeline-time {

    color: #64748b;

    font-size: 11px;

    margin-top: 10px;
}


/* =========================================================
   INVESTIGATION NOTES
========================================================= */

.comment-form textarea {

    width: 100%;

    min-height: 130px;

    resize: vertical;

    padding: 14px;

    background: #0f172a;

    color: #f8fafc;

    border:
        1px solid #334155;

    border-radius: 9px;

    outline: none;

    font-family: Arial, sans-serif;

    font-size: 14px;

    line-height: 1.5;

    display: block;
}


.comment-form textarea:focus {

    border-color: #38bdf8;

    box-shadow:
        0 0 0 2px
        rgba(56, 189, 248, 0.12);
}


.comment-form-footer {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-top: 12px;
}


.comment-form-footer span {

    color: #64748b;

    font-size: 11px;
}


.comment-button {

    border: none;

    padding: 11px 17px;

    border-radius: 8px;

    background: #2563eb;

    color: white;

    cursor: pointer;

    font-weight: 600;

    font-size: 13px;
}


.comment-button:hover {

    background: #1d4ed8;
}


/* =========================================================
   COMMENTS
========================================================= */

.comments-list {

    margin-top: 25px;
}


.comment-item {

    background: #0f172a;

    border:
        1px solid #263244;

    border-radius: 10px;

    padding: 16px;

    margin-bottom: 12px;
}


.comment-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-bottom: 12px;
}


.comment-author {

    display: flex;

    align-items: center;

    flex-wrap: wrap;

    gap: 7px;
}


.comment-author strong {

    color: #e2e8f0;
}


.role {

    display: inline-block;

    padding: 3px 8px;

    border-radius: 12px;

    background: #312e81;

    color: #c7d2fe;

    font-size: 10px;

    text-transform: uppercase;

    font-weight: 700;
}


.comment-date {

    color: #64748b;

    font-size: 11px;

    white-space: nowrap;
}


.comment-text {

    color: #cbd5e1;

    line-height: 1.6;

    white-space: pre-wrap;

    word-break: break-word;
}


.comment-empty {

    color: #64748b;

    text-align: center;

    padding: 25px 10px;
}


/* =========================================================
   EVIDENCE
========================================================= */

.evidence-help {

    color: #64748b;

    font-size: 11px;

    line-height: 1.6;

    margin: 10px 0 15px;
}


input[type="file"] {

    width: 100%;

    padding: 12px;

    background: #0f172a;

    color: #cbd5e1;

    border:
        1px solid #334155;

    border-radius: 8px;
}


input[type="file"]::file-selector-button {

    background: #334155;

    color: white;

    border: none;

    padding: 8px 12px;

    border-radius: 6px;

    margin-right: 10px;

    cursor: pointer;
}


.evidence-list {

    margin-top: 22px;
}


.evidence-item {

    background: #0f172a;

    border:
        1px solid #263244;

    border-radius: 10px;

    padding: 16px;

    margin-bottom: 12px;
}


.evidence-top {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 15px;
}


.evidence-name {

    color: #e2e8f0;

    font-weight: 700;

    word-break: break-word;
}


.evidence-meta {

    color: #64748b;

    font-size: 11px;

    margin-top: 7px;

    line-height: 1.6;
}


.evidence-hash {

    margin-top: 12px;

    padding: 10px;

    background: #111827;

    border:
        1px solid #263244;

    border-radius: 7px;

    color: #94a3b8;

    font-family: monospace;

    font-size: 10px;

    word-break: break-all;
}


.evidence-hash strong {

    color: #cbd5e1;
}


.evidence-actions {

    margin-top: 12px;
}


.evidence-download {

    display: inline-block;

    padding: 9px 13px;

    background: #0891b2;

    color: white;

    text-decoration: none;

    border-radius: 7px;

    font-size: 12px;

    font-weight: 700;
}


.evidence-download:hover {

    background: #0e7490;
}


/* =========================================================
   ACTIONS
========================================================= */

.actions {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;
}


.btn {

    display: inline-block;

    padding: 11px 16px;

    border-radius: 8px;

    color: white;

    background: #2563eb;

    text-decoration: none;

    font-weight: 600;

    font-size: 14px;
}


.btn:hover {

    background: #1d4ed8;
}


.btn-purple {

    background: #7c3aed;
}


.btn-cyan {

    background: #0891b2;
}


.btn-green {

    background: #059669;
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    color: #64748b;

    text-align: center;

    padding: 25px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:900px) {

    .grid {

        grid-template-columns: 1fr;
    }

}


@media(max-width:700px) {

    .container {

        padding: 15px;
    }


    .navbar {

        flex-direction: column;

        align-items: flex-start;

        gap: 15px;
    }


    .navbar a {

        margin-left: 0;

        margin-right: 12px;
    }


    .detail-row {

        flex-direction: column;

        gap: 5px;
    }


    .detail-value {

        text-align: left;
    }


    .timeline-values {

        grid-template-columns: 1fr;
    }


    .comment-header {

        flex-direction: column;

        align-items: flex-start;
    }


    .comment-form-footer {

        flex-direction: column;

        align-items: flex-start;
    }


    .evidence-top {

        flex-direction: column;

        align-items: flex-start;
    }

}

</style>

</head>


<body>


<!-- =====================================================
     NAVBAR
===================================================== -->

<div class="navbar">

    <div class="brand">

        🛡 Security Incident Ticketing

    </div>


    <div>

        <?php if (
            $_SESSION['role'] === 'admin'
        ): ?>

            <a href="../admin/dashboard.php">
                Dashboard
            </a>

            <a href="../admin/incidents.php">
                Incidents
            </a>

            <a href="../reports/incidents-report.php">
                Reports
            </a>

        <?php else: ?>

            <a href="../analyst/dashboard.php">
                Dashboard
            </a>

            <a href="../analyst/assigned-incidents.php">
                My Incidents
            </a>

        <?php endif; ?>


        <a href="../auth/logout.php">
            Logout
        </a>

    </div>

</div>


<div class="container">


    <!-- =================================================
         SUCCESS MESSAGE
    ================================================== -->

    <?php if ($successMessage): ?>

        <div class="success">

            ✓

            <?= e(
                $successMessage
            ) ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         ERROR MESSAGE
    ================================================== -->

    <?php if ($commentError): ?>

        <div class="error">

            ⚠

            <?= e(
                $commentError
            ) ?>

        </div>

    <?php endif; ?>


    <?php if ($evidenceError): ?>

        <div class="error">

            ⚠

            <?= e(
                $evidenceError
            ) ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         INCIDENT HEADER
    ================================================== -->

    <div class="incident-header">

        <div class="ticket">

            <?= e(
                $incident['ticket_number']
            ) ?>

        </div>


        <h1>

            <?= e(
                $incident['title']
            ) ?>

        </h1>


        <div class="badges">


            <span class="badge category">

                <?= e(
                    $incident['category_name']
                    ?? 'Uncategorized'
                ) ?>

            </span>


            <span
                class="badge <?= e(
                    $severityClass[
                        $incident['severity']
                    ]
                    ??
                    'medium'
                ) ?>"
            >

                <?= e(
                    ucfirst(
                        $incident['severity']
                    )
                ) ?>

            </span>


            <span
                class="badge <?= e(
                    $statusClass[
                        $incident['status']
                    ]
                    ??
                    'open'
                ) ?>"
            >

                <?= e(
                    $statusLabels[
                        $incident['status']
                    ]
                    ??
                    ucfirst(
                        $incident['status']
                    )
                ) ?>

            </span>


        </div>

    </div>


    <!-- =================================================
         MAIN GRID
    ================================================== -->

    <div class="grid">


        <!-- =================================================
             LEFT COLUMN
        ================================================== -->

        <div>


            <!-- DESCRIPTION -->

            <div class="card">

                <h2>
                    Incident Description
                </h2>

                <div class="description">

                    <?= e(
                        $incident['description']
                    ) ?>

                </div>

            </div>


            <!-- =================================================
                 INVESTIGATION NOTES
            ================================================== -->

            <div class="card">

                <h2>
                    📝 Investigation Notes
                </h2>


                <form
                    class="comment-form"
                    method="POST"
                    action="add-comment.php"
                >

                    <?= csrfField() ?>


                    <input
                        type="hidden"
                        name="incident_id"
                        value="<?= e(
                            (string)$incidentId
                        ) ?>"
                    >


                    <textarea
                        name="comment"
                        maxlength="5000"
                        placeholder="Enter investigation findings, evidence observations, analysis, or resolution notes..."
                        required
                    ></textarea>


                    <div class="comment-form-footer">

                        <span>
                            Maximum 5000 characters
                        </span>


                        <button
                            type="submit"
                            class="comment-button"
                        >
                            Add Investigation Note
                        </button>

                    </div>

                </form>


                <div class="comments-list">


                    <?php if (!$comments): ?>

                        <div class="comment-empty">

                            No investigation notes yet.

                        </div>

                    <?php else: ?>


                        <?php foreach (
                            $comments
                            as $comment
                        ): ?>


                            <div class="comment-item">


                                <div class="comment-header">


                                    <div class="comment-author">


                                        <strong>

                                            <?= e(
                                                $comment[
                                                    'user_name'
                                                ]
                                                ??
                                                'Unknown User'
                                            ) ?>

                                        </strong>


                                        <span class="role">

                                            <?= e(
                                                ucfirst(
                                                    $comment[
                                                        'user_role'
                                                    ]
                                                    ??
                                                    'user'
                                                )
                                            ) ?>

                                        </span>


                                    </div>


                                    <span class="comment-date">

                                        <?= e(
                                            $comment[
                                                'created_at'
                                            ]
                                        ) ?>

                                    </span>


                                </div>


                                <div class="comment-text">

                                    <?= e(
                                        $comment[
                                            'comment'
                                        ]
                                    ) ?>

                                </div>


                            </div>


                        <?php endforeach; ?>


                    <?php endif; ?>


                </div>

            </div>


            <!-- =================================================
                 EVIDENCE MANAGEMENT
            ================================================== -->

            <div class="card">

                <h2>
                    📎 Incident Evidence
                </h2>


                <!-- UPLOAD FORM -->

                <form
                    method="POST"
                    action="upload-evidence.php"
                    enctype="multipart/form-data"
                >

                    <?= csrfField() ?>


                    <input
                        type="hidden"
                        name="incident_id"
                        value="<?= e(
                            (string)$incidentId
                        ) ?>"
                    >


                    <input
                        type="file"
                        name="evidence"
                        required
                    >


                    <div class="evidence-help">

                        Allowed:
                        JPG, PNG, GIF, PDF, TXT,
                        LOG, CSV, DOC, DOCX, XLS, XLSX

                        <br>

                        Maximum size: 10 MB

                    </div>


                    <button
                        type="submit"
                        class="comment-button"
                    >
                        📤 Upload Evidence
                    </button>

                </form>


                <!-- EVIDENCE LIST -->

                <div class="evidence-list">


                    <?php if (
                        !$evidenceFiles
                    ): ?>


                        <div class="comment-empty">

                            No evidence files uploaded yet.

                        </div>


                    <?php else: ?>


                        <?php foreach (
                            $evidenceFiles
                            as $evidence
                        ): ?>


                            <div class="evidence-item">


                                <div class="evidence-top">


                                    <div>


                                        <div class="evidence-name">

                                            📄

                                            <?= e(
                                                $evidence[
                                                    'original_name'
                                                ]
                                            ) ?>

                                        </div>


                                        <div class="evidence-meta">

                                            Size:

                                            <?= e(
                                                formatFileSize(
                                                    (int)$evidence[
                                                        'file_size'
                                                    ]
                                                )
                                            ) ?>

                                            <br>

                                            Type:

                                            <?= e(
                                                $evidence[
                                                    'mime_type'
                                                ]
                                            ) ?>

                                            <br>

                                            Uploaded by:

                                            <?= e(
                                                $evidence[
                                                    'uploader_name'
                                                ]
                                                ??
                                                'Unknown User'
                                            ) ?>

                                            <br>

                                            Uploaded:

                                            <?= e(
                                                $evidence[
                                                    'created_at'
                                                ]
                                            ) ?>

                                        </div>


                                    </div>


                                </div>


                                <!-- SHA-256 -->

                                <div class="evidence-hash">

                                    <strong>
                                        SHA-256:
                                    </strong>

                                    <?= e(
                                        $evidence[
                                            'file_hash'
                                        ]
                                    ) ?>

                                </div>


                                <!-- DOWNLOAD -->

                                <div class="evidence-actions">

                                    <a
                                        href="download-evidence.php?id=<?= e(
                                            (string)$evidence['id']
                                        ) ?>"
                                        class="evidence-download"
                                    >
                                        ⬇ Download Evidence
                                    </a>

                                </div>


                            </div>


                        <?php endforeach; ?>


                    <?php endif; ?>


                </div>

            </div>


            <!-- =================================================
                 ACTIVITY TIMELINE
            ================================================== -->

            <div class="card">

                <h2>
                    Activity History
                </h2>


                <?php if (!$activities): ?>

                    <div class="empty">

                        No activity has been recorded.

                    </div>

                <?php else: ?>


                    <div class="timeline">


                        <?php foreach (
                            $activities
                            as $activity
                        ): ?>


                            <div class="timeline-item">


                                <div class="timeline-dot"></div>


                                <div class="timeline-content">


                                    <div class="timeline-title">

                                        <?= e(
                                            $activity['action']
                                        ) ?>

                                    </div>


                                    <div class="timeline-user">

                                        👤

                                        <?= e(
                                            $activity[
                                                'user_name'
                                            ]
                                            ??
                                            'System'
                                        ) ?>

                                        <?php if (
                                            !empty(
                                                $activity[
                                                    'user_role'
                                                ]
                                            )
                                        ): ?>

                                            (

                                            <?= e(
                                                ucfirst(
                                                    $activity[
                                                        'user_role'
                                                    ]
                                                )
                                            ) ?>

                                            )

                                        <?php endif; ?>

                                    </div>


                                    <?php if (
                                        $activity[
                                            'old_value'
                                        ] !== null
                                        ||
                                        $activity[
                                            'new_value'
                                        ] !== null
                                    ): ?>


                                        <div class="timeline-values">


                                            <div class="value-box">

                                                <div class="value-label">
                                                    Previous
                                                </div>

                                                <div class="value-text">

                                                    <?= e(
                                                        $activity[
                                                            'old_value'
                                                        ]
                                                        ??
                                                        '—'
                                                    ) ?>

                                                </div>

                                            </div>


                                            <div class="value-box">

                                                <div class="value-label">
                                                    New
                                                </div>

                                                <div class="value-text">

                                                    <?= e(
                                                        $activity[
                                                            'new_value'
                                                        ]
                                                        ??
                                                        '—'
                                                    ) ?>

                                                </div>

                                            </div>


                                        </div>


                                    <?php endif; ?>


                                    <?php if (
                                        !empty(
                                            $activity[
                                                'comment'
                                            ]
                                        )
                                    ): ?>

                                        <div class="timeline-comment">

                                            💬

                                            <?= e(
                                                $activity[
                                                    'comment'
                                                ]
                                            ) ?>

                                        </div>

                                    <?php endif; ?>


                                    <div class="timeline-time">

                                        <?= e(
                                            $activity[
                                                'created_at'
                                            ]
                                        ) ?>

                                    </div>


                                </div>

                            </div>


                        <?php endforeach; ?>


                    </div>


                <?php endif; ?>


            </div>


        </div>


        <!-- =================================================
             RIGHT COLUMN
        ================================================== -->

        <div>


            <!-- INCIDENT DETAILS -->

            <div class="card">

                <h2>
                    Incident Details
                </h2>


                <div class="detail-row">

                    <div class="detail-label">
                        Ticket
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'ticket_number'
                            ]
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Category
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'category_name'
                            ]
                            ??
                            'N/A'
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Severity
                    </div>

                    <div class="detail-value">

                        <?= e(
                            ucfirst(
                                $incident[
                                    'severity'
                                ]
                            )
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Status
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $statusLabels[
                                $incident[
                                    'status'
                                ]
                            ]
                            ??
                            ucfirst(
                                $incident[
                                    'status'
                                ]
                            )
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Reporter
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'reporter_name'
                            ]
                            ??
                            'N/A'
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Reporter Email
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'reporter_email'
                            ]
                            ??
                            'N/A'
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Assigned Analyst
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'analyst_name'
                            ]
                            ??
                            'Not Assigned'
                        ) ?>

                    </div>

                </div>


                <?php if (
                    !empty(
                        $incident[
                            'analyst_email'
                        ]
                    )
                ): ?>

                    <div class="detail-row">

                        <div class="detail-label">
                            Analyst Email
                        </div>

                        <div class="detail-value">

                            <?= e(
                                $incident[
                                    'analyst_email'
                                ]
                            ) ?>

                        </div>

                    </div>

                <?php endif; ?>


                <div class="detail-row">

                    <div class="detail-label">
                        Created
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'created_at'
                            ]
                        ) ?>

                    </div>

                </div>


                <div class="detail-row">

                    <div class="detail-label">
                        Updated
                    </div>

                    <div class="detail-value">

                        <?= e(
                            $incident[
                                'updated_at'
                            ]
                        ) ?>

                    </div>

                </div>


            </div>


            <!-- =================================================
                 ACTIONS
            ================================================== -->

            <div class="card">

                <h2>
                    Actions
                </h2>


                <div class="actions">


                    <?php if (
                        $_SESSION['role']
                        ===
                        'admin'
                    ): ?>


                        <a
                            class="btn btn-purple"
                            href="edit.php?id=<?= e(
                                (string)$incidentId
                            ) ?>"
                        >
                            ✏ Edit
                        </a>


                        <a
                            class="btn btn-cyan"
                            href="assign.php?id=<?= e(
                                (string)$incidentId
                            ) ?>"
                        >
                            👤 Assign
                        </a>


                    <?php endif; ?>


                    <a
                        class="btn btn-green"
                        href="update-status.php?id=<?= e(
                            (string)$incidentId
                        ) ?>"
                    >
                        🔄 Update Status
                    </a>


                </div>

            </div>


        </div>


    </div>


</div>


</body>

</html>